<h1>Settings</h1>
<div>
    <a href="change_password.php">Change Password</a> 
</div>