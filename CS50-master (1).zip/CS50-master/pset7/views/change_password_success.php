<p>
        Password successfully changed.
</p>