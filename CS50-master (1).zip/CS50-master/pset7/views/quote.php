<h1><?= $stock["name"] ?> (<?= $stock["symbol"] ?>)</h1>
<h3>Price: $<?= $stock["price"] ?> USD</h3>