<?php

    // configuration
    require("../includes/config.php");
    
    // render settings page
    render("settings.php", ["title" => "Settings"]);
?>