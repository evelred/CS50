#[whodunit](http://cdn.cs50.net/2016/x/psets/4/pset4/pset4.html#whodunit)

Welcome to Tudor Mansion. Your host, Mr. John Boddy, has met an untimely end—he’s the victim of foul play. To win this game, you must determine whodunit.

Unfortunately for you (though even more unfortunately for Mr. Boddy), the only evidence you have is a 24-bit BMP file called clue.bmp, pictured below, that Mr. Boddy whipped up on his computer in his final moments. Hidden among this file’s red "noise" is a drawing of whodunit.

Write a program called whodunit in a file called whodunit.c that reveals Mr. Boddy’s drawing.

![clue.bmp](http://i.imgur.com/ZzxZ9WT.png "clue.bmp")

##solution
![verdict.bmp](http://i.imgur.com/5ioQHx5.png "verdict.bmp")
